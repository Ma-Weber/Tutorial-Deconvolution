Design of deconvolution filters
===============================

.. automodule:: PyDynamic.deconvolution.fit_filter
    :noindex:
